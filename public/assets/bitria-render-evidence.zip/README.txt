These are screenshots of original traces opened in native Chrome 156 DevTools Performance, not drawn summaries.
Before: render-before/run-01, after: render-after/run-02, selected as each group median React root time.
Import *.chrome-trace.json in Chrome DevTools Performance.
React render counts and root times come from the custom fiber hook, not Chrome Performance summary. The JSON includes all 10 runs and per-commit fibers.
The Chrome trace includes recording overhead around the 12-second replay; before range ~12.40s, after ~12.18s. Do not treat the displayed screenshot totals as the React table numbers or as a 5-run median.
Host load was not identical. This is a local development replay experiment, not production user latency.
